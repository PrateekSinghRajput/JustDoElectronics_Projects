# TinyGPS
A compact Arduino NMEA (GPS) parsing library